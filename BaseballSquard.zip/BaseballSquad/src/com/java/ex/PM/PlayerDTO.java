package com.java.ex.PM;

public class PlayerDTO {
	private String player_name;
	private int player_age;
	private int player_height;
	private int player_weight;
	private int player_backnumber;
	private String player_pitchingandhitting;
	private String player_position;

	public String getPlayer_name() {
		return player_name;
	}

	public void setPlayer_name(String player_name) {
		this.player_name = player_name;
	}

	public int getPlayer_age() {
		return player_age;
	}

	public void setPlayer_age(int player_age) {
		this.player_age = player_age;
	}

	public int getPlayer_height() {
		return player_height;
	}

	public void setPlayer_height(int player_height) {
		this.player_height = player_height;
	}

	public int getPlayer_weight() {
		return player_weight;
	}

	public void setPlayer_weight(int player_weight) {
		this.player_weight = player_weight;
	}

	public int getPlayer_backnumber() {
		return player_backnumber;
	}

	public void setPlayer_backnumber(int player_backnumber) {
		this.player_backnumber = player_backnumber;
	}

	public String getPlayer_pitchingandhitting() {
		return player_pitchingandhitting;
	}

	public void setPlayer_pitchingandhitting(String player_pitchingandhitting) {
		this.player_pitchingandhitting = player_pitchingandhitting;
	}

	public String getPlayer_position() {
		return player_position;
	}

	public void setPlayer_position(String player_position) {
		this.player_position = player_position;
	}
	
}