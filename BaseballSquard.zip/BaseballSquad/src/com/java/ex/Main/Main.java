package com.java.ex.Main;

import com.java.ex.Login.LoginForm;

public class Main {
	MainFrame mainForm;
	LoginForm loginForm;
	public static void main(String[] args) {
		Main main = new Main();
		main.loginForm = new LoginForm();
	}
}
