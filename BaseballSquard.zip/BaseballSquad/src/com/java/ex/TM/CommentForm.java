package com.java.ex.TM;

import java.awt.Color;

public class CommentForm {
	Color color = new Color(128, 0, 33);
}
