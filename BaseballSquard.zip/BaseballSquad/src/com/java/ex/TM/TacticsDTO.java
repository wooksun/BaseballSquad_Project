package com.java.ex.TM;

public class TacticsDTO {
	private int tactics_id;
	private String tactics_name;
	private String dh;
	private String c;
	private String b1;
	private String b2;
	private String b3;
	private String ss;
	private String lf;
	private String cf;
	private String rf;
	private String ch1;
	private String ch2;
	private String ch3;
	private String sp1;
	private String sp2;
	private String sp3;
	private String sp4;
	private String sp5;
	private String rp1;
	private String rp2;
	private String cp1;
	private String cp2;
	public int getTactics_id() {
		return tactics_id;
	}
	public void setTactics_id(int tactics_id) {
		this.tactics_id = tactics_id;
	}
	public String getTactics_name() {
		return tactics_name;
	}
	public void setTactics_name(String tactics_name) {
		this.tactics_name = tactics_name;
	}
	public String getDh() {
		return dh;
	}
	public void setDh(String dh) {
		this.dh = dh;
	}
	public String getC() {
		return c;
	}
	public void setC(String c) {
		this.c = c;
	}
	public String getB1() {
		return b1;
	}
	public void setB1(String b1) {
		this.b1 = b1;
	}
	public String getB2() {
		return b2;
	}
	public void setB2(String b2) {
		this.b2 = b2;
	}
	public String getB3() {
		return b3;
	}
	public void setB3(String b3) {
		this.b3 = b3;
	}
	public String getSs() {
		return ss;
	}
	public void setSs(String ss) {
		this.ss = ss;
	}
	public String getLf() {
		return lf;
	}
	public void setLf(String lf) {
		this.lf = lf;
	}
	public String getCf() {
		return cf;
	}
	public void setCf(String cf) {
		this.cf = cf;
	}
	public String getRf() {
		return rf;
	}
	public void setRf(String rf) {
		this.rf = rf;
	}
	public String getCh1() {
		return ch1;
	}
	public void setCh1(String ch1) {
		this.ch1 = ch1;
	}
	public String getCh2() {
		return ch2;
	}
	public void setCh2(String ch2) {
		this.ch2 = ch2;
	}
	public String getCh3() {
		return ch3;
	}
	public void setCh3(String ch3) {
		this.ch3 = ch3;
	}
	public String getSp1() {
		return sp1;
	}
	public void setSp1(String sp1) {
		this.sp1 = sp1;
	}
	public String getSp2() {
		return sp2;
	}
	public void setSp2(String sp2) {
		this.sp2 = sp2;
	}
	public String getSp3() {
		return sp3;
	}
	public void setSp3(String sp3) {
		this.sp3 = sp3;
	}
	public String getSp4() {
		return sp4;
	}
	public void setSp4(String sp4) {
		this.sp4 = sp4;
	}
	public String getSp5() {
		return sp5;
	}
	public void setSp5(String sp5) {
		this.sp5 = sp5;
	}
	public String getRp1() {
		return rp1;
	}
	public void setRp1(String rp1) {
		this.rp1 = rp1;
	}
	public String getRp2() {
		return rp2;
	}
	public void setRp2(String rp2) {
		this.rp2 = rp2;
	}
	public String getCp1() {
		return cp1;
	}
	public void setCp1(String cp1) {
		this.cp1 = cp1;
	}
	public String getCp2() {
		return cp2;
	}
	public void setCp2(String cp2) {
		this.cp2 = cp2;
	}
	
	

}

